package in.java.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

public class IO {
	//基于磁盘文件：FileInputStream、FileOutputSteam、FileReader、FileWriter
	//基于内存：ByteArrayInputStream ByteArrayOutputStream（ps:字节数组都是在内存中产生）
	//基于网络：SocketInputStream、SocketOutputStream（ps:网络通信时传输数据）
	
	//InputStream、OutputStream（字节流）
	public void 字节流() throws IOException{
		//读取文件(字节流)
        InputStream in = new FileInputStream("d:\\1.txt");
        //写入相应的文件
        OutputStream out = new FileOutputStream("d:\\2.txt");
        //一次性取多少字节
        byte[] bytes = new byte[2048];
        //接受读取的内容(n就代表的相关数据，只不过是数字的形式)
        int n = -1;
        //循环取出数据
        while ((n = in.read(bytes,0,bytes.length)) != -1) {
            //转换成字符串
            String str = new String(bytes,0,n,"GBK"); //#这里可以实现字节到字符串的转换，比较实用
            System.out.println(str);
            //写入相关文件
            out.write(bytes, 0, n);
        }
        //关闭流
        in.close();
        out.close();
        
	}
	
	//BufferedInputStream、BufferedOutputStream（缓存字节流）使用方式和字节流差不多，但是效率更高（推荐使用）
	public void 缓存字节流() throws UnsupportedEncodingException, IOException{
        //读取文件(缓存字节流)
        BufferedInputStream in = new BufferedInputStream(new FileInputStream("d:\\1.txt"));
        //写入相应的文件
        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream("d:\\2.txt"));
        //读取数据
        //一次性取多少字节
        byte[] bytes = new byte[2048];
        //接受读取的内容(n就代表的相关数据，只不过是数字的形式)
        int n = -1;
        //循环取出数据
        while ((n = in.read(bytes,0,bytes.length)) != -1) {
            //转换成字符串
            String str = new String(bytes,0,n,"GBK");
            System.out.println(str);
            //写入相关文件
            out.write(bytes, 0, n);
        }
        //清楚缓存
        out.flush();
        //关闭流
        in.close();
        out.close();		
	}
	
	
	//InputStreamReader、OutputStreamWriter（字节流，这种方式不建议使用，不能直接字节长度读写）。使用范围用做字符转换
	public void 字节流Reader() throws IOException, FileNotFoundException{
		//读取文件(字节流)
        InputStreamReader in = new InputStreamReader(new FileInputStream("d:\\1.txt"),"GBK");
        //写入相应的文件
        OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("d:\\2.txt"));
        //读取数据
        //循环取出数据
        byte[] bytes = new byte[1024];
        int len = -1;
        while ((len = in.read()) != -1) {
            System.out.println(len);
            //写入相关文件
            out.write(len);
        }
        //清楚缓存
        out.flush();
        //关闭流
        in.close();
        out.close();
	}
	
	//BufferedReader、BufferedWriter(缓存流，提供readLine方法读取一行文本)
	public void 缓存流Reader() throws IOException, FileNotFoundException{
		//读取文件(字符流)
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("d:\\1.txt"),"GBK"));//这里主要是涉及中文
        //BufferedReader in = new BufferedReader(new FileReader("d:\\1.txt")));
        //写入相应的文件
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("d:\\2.txt"),"GBK"));
        //BufferedWriter out = new BufferedWriter(new FileWriter("d:\\2.txt"))；
        //读取数据
        //循环取出数据
        String str = null;
        while ((str = in.readLine()) != null) {
            System.out.println(str);
            //写入相关文件
            out.write(str);
            out.newLine();
        }
        //清楚缓存
        out.flush();
        //关闭流
        in.close();
        out.close();
	}
	
	
}
