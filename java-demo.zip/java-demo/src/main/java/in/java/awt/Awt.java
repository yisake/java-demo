package in.java.awt;

public class Awt {

}
