package in.java.awt;

public class AwtUtil {

}
