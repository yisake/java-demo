package in.java.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Sql {
	private static Connection conn=getConn();; 
	/**
	3.1 读取方法1 – 通过索引来遍历读取
	    while(rs.next()){
	        int id = rs.getInt(1);
	        String name = rs.getString(2);
	        String gender = rs.getString(3);
	        System.out.println("id:"+id+" 姓名："+name+" 性别："+gender);
	    }
	
	3.2 读取方法2 – 通过字段名称来读取
	强调一下，这个传入的字段名称可以不区分大小写，因为在mysql中就是不区分的
	    while(rs.next()){
	        int id = rs.getInt("id");
	        String name = rs.getString("name");
	        String gender = rs.getString("gender");
	        System.out.println("id:"+id+" 姓名："+name+" 性别："+gender);
	    }
	 */
			
    private static Connection getConn() {
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/test?useSSL=false&serverTimezone=UTC";
        String username = "root";
        String password = "123";
        Connection conn = null;
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, username, password);
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        Sql.conn=conn;
        return conn;
    }
    
    private static void closeConn() throws SQLException{
    	Sql.conn.close();
    }
    
    private static int insert(String username, String password) {
        int i = 0;
        String sql = "insert into users (username,password) values(?,?)";
        PreparedStatement pstmt;
        try {
            pstmt = Sql.conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            i = pstmt.executeUpdate();
            System.out.println("resutl: " + i);
            pstmt.close();
            Sql.conn.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return i;
    }

    private static int update(String oldName, String newPass) {
        int i = 0;
        String sql = "update users set password='" + newPass
                + "' where username='" + oldName + "'";
        PreparedStatement pstmt;
        try {
            pstmt = conn.prepareStatement(sql);

            i = pstmt.executeUpdate();
            System.out.println("resutl: " + i);

            pstmt.close();
            conn.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return i;
    }
    
    private static int delete(String username) {
        int i = 0;
        String sql = "delete users where username='" + username + "'";
        PreparedStatement pstmt;
        try {
            pstmt = conn.prepareStatement(sql);

            i = pstmt.executeUpdate();
            System.out.println("resutl: " + i);

            pstmt.close();
            conn.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        return i;
    }
    

    private static ArrayList<Map<String, Object>> query(String sql) {
    	ArrayList<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
        PreparedStatement pstmt;
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            //获得结果集结构信息,元数据
            ResultSetMetaData md=rs.getMetaData();
            //获取所有字段数量
            System.out.println("获取字段数:"+md.getColumnCount());
            while (rs.next()) {
            	Map<String,Object> rowData = new HashMap<String,Object>();
    			for (int i = 1; i <= md.getColumnCount(); i++) {
    				rowData.put(md.getColumnName(i), rs.getObject(i));
    				//获取字段类型
    				System.out.println("获取字段:");
    				System.out.println("columnType:"+md.getColumnType(i));
    				System.out.println("columnTypeName:"+md.getColumnTypeName(i));
    				//获取字段名称
    				System.out.println(md.getColumnName(i)+":"+rs.getObject(i));
    			}
    			list.add(rowData);
            }
            rs.close();
            pstmt.close();
            return list;
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
		return list;
    }    

    /**
     * @param args
     * @throws SQLException 
     */
    public static void main(String[] args) throws SQLException {
        Sql.query("select * from user_po_jo");
        ArrayList<Map<String, Object>> tUsersList=query("select * from t_user");
        System.out.println(tUsersList.get(0).get("account"));
        System.out.println(tUsersList.get(1).get("account"));
        System.out.println(tUsersList.get(0).get("create_time"));
        //insert("CDE", "123");
        //update("CoderDream", "456");
        //delete("CoderDream");
        //query();
        Sql.closeConn();
    }
}	
