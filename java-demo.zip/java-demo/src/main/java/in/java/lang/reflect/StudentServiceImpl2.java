package in.java.lang.reflect;


public class StudentServiceImpl2 {
	 
    public Student createStudent(String name ,int age) {
        Student student = new Student("lishengtao",32);
        return student;
    }
    
    public void test() {
    	Student student = new Student("test",32);
    }
}
