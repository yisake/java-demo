package in.java.lang.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.*;



//@Target：用于描述注解的使用范围（注解可以用在什么地方）。
//ElementType.CONSTRUCTOR：构造器。
//ElementType.FIELD：成员变量。
//ElementType.LOCAL_VARIABLE：局部变量。
//ElementType.PACKAGE：包。
//ElementType.PARAMETER：参数。
//ElementType.METHOD：方法。
//ElementType.TYPE：类、接口(包括注解类型) 或enum声明。
//@Retention：注解的生命周期，用于表示该注解会在什么时期保留。
//RetentionPolicy.RUNTIME：运行时保留，这样就可以通过反射获得了。
//RetentionPolicy.CLASS：在class文件中保留。
//RetentionPolicy.SOURCE：在源文件中保留。
//@Documented：表示该注解会被作为被标注的程序成员的公共API，因此可以被例如javadoc此类的工具文档化。
//@Inherited：表示该注解是可被继承的（如果一个使用了@Inherited修饰的annotation类型被用于一个class，则这个annotation将被用于该class的子类）。
//了解了这些基础知识之后，接着完成上述定义的@ValidateInt，我们定义一个Cat类然后在它的成员变量中使用@ValidateInt，并通过反射进行数据校验。
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@Documented
public @interface 注解2 {

    // 它们看起来像是定义一个函数，但其实这是注解中的属性
    int maxLength();

    int minLength();

}
