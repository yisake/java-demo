package in.java.lang.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;

public class 注解 {
	
	// 适用类、接口（包括注解类型）或枚举
	@Retention(RetentionPolicy.RUNTIME)
	@Target(ElementType.TYPE)
	public @interface ClassInfo1 {
	    String value();
	}
	
	// 适用类、接口（包括注解类型）或枚举
	@Retention(RetentionPolicy.RUNTIME)
	@Target(ElementType.TYPE)
	public @interface ClassInfo2 {
	    String value();
	}
	
	// 适用field属性，也包括enum常量
	@Retention(RetentionPolicy.RUNTIME)
	@Target(ElementType.FIELD)
	public @interface FieldInfo {
	    int[] value();
	}
	
	// 适用方法
	@Retention(RetentionPolicy.RUNTIME)
	@Target(ElementType.METHOD)
	public @interface MethodInfo {
	    String name() default "long";
	    String data();
	    int age() default 27;
	}
	
	@ClassInfo1("info1")
	@ClassInfo2("info2")
	public class TestRuntimeAnnotation {
	 
	    @FieldInfo(value = {1, 2})
	    public String fieldInfo = "FiledInfo";
	 
	    @FieldInfo(value = {10086})
	    public int fieldNum = 100;
	 
	    @MethodInfo(name = "BlueBird", data = "Big")
	    public String getMethodInfo() {
	        return TestRuntimeAnnotation.class.getSimpleName();
	    }
	}

	public static void main(String[] args) {
	    StringBuffer sb = new StringBuffer();
	    Class<?> cls = TestRuntimeAnnotation.class;	    
	    Annotation[] annos= cls.getAnnotations();
	    for(int i=0;i<annos.length;i++) {
	    	System.out.println(annos[i]);
	    }
	    
	    sb.append("\nClass注解：").append("\n");
	    ClassInfo1 classInfo1 = cls.getAnnotation(ClassInfo1.class);
	    if (classInfo1 != null) {
	        sb.append(Modifier.toString(cls.getModifiers())).append(" ").append(cls.getSimpleName()).append("\n");
	        sb.append("注解值: ").append(classInfo1.value()).append("\n");
	    }	    
	    ClassInfo2 classInfo2 = cls.getAnnotation(ClassInfo2.class);
	    if (classInfo2 != null) {
	        sb.append(Modifier.toString(cls.getModifiers())).append(" ")
	                .append(cls.getSimpleName()).append("\n");
	        sb.append("注解值: ").append(classInfo2.value()).append("\n");
	    }

		//getFields()：获得某个类的所有的公共（public）的字段，包括父类中的字段。 
		//getDeclaredFields()：获得某个类的所有声明的字段，即包括public、private和proteced，但是不包括父类的申明字段。
		//同样类似的还有getConstructors()和getDeclaredConstructors()、getMethods()和getDeclaredMethods()，这两者分别表示获取某个类的方法、构造函数。
	    sb.append("\nField注解：").append("\n");
	    Field[] fields = cls.getDeclaredFields();
	    for (Field field : fields) {
	        FieldInfo fieldInfo = field.getAnnotation(FieldInfo.class);
	        if (fieldInfo != null) {
	            sb.append(Modifier.toString(field.getModifiers())).append(" ")
                .append(field.getType().getSimpleName()).append(" ")
                .append(field.getName()).append("\n");
	            sb.append("注解值: ").append(Arrays.toString(fieldInfo.value())).append("\n");
	        }
	    }
	 
	    sb.append("\nMethod注解：").append("\n");
	    Method[] methods = cls.getDeclaredMethods();
	    for (Method method : methods) {
	        MethodInfo methodInfo = method.getAnnotation(MethodInfo.class);
	        if (methodInfo != null) {
	            sb.append(Modifier.toString(method.getModifiers())).append(" ")
                .append(method.getReturnType().getSimpleName()).append(" ")
                .append(method.getName()).append("\n");
	            sb.append("注解值: ").append("\n");
	            sb.append("name: ").append(methodInfo.name()).append("\n");
	            sb.append("data: ").append(methodInfo.data()).append("\n");
	            sb.append("age: ").append(methodInfo.age()).append("\n");
	        }
	    }
	    System.out.print(sb.toString());
	}
}
