package in.java.lang.reflect;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import org.testng.annotations.Test;

public class 反射 {
	
	//见注解详细例子
	//获取一个类的所有方法名
	@Test
    public void getReflectAllMethod(Class<?> mLocalClass) {
        Class<?> c;
        c = mLocalClass;
        try {
            do {
                Method[] m = c.getDeclaredMethods();  // 取得全部的方法    

                for (int i = 0; i < m.length; i++) {
                    String mod = Modifier.toString(m[i].getModifiers());  // 取得访问权限  
                    String metName = m[i].getName();  // 取得方法名称  
                    Class<?> ret = m[i].getReturnType(); // 取得返回值类型    
                    Class<?>[] param = m[i].getParameterTypes();// 得到全部的参数类型  
                    Class<?>[] exc = m[i].getExceptionTypes(); // 得到全部的异常    
                    System.out.print(mod + " "); //输出每一方法的访问权限
                    System.out.print(ret + " "); //输出每一方法的返回值类型  
                    System.out.print(metName + " (");;//输出每一方法的名字  
                    for (int x = 0; x < param.length; x++) { //循环输出每一方法的参数的类型  
                        System.out.print(param[x] + "arg-" + x);
                        if (x < (param.length - 1)) {
                            System.out.print(",");
                        }
                    }

                    System.out.print(") ");
                    if (exc.length > 0) { // 有异常抛出  
                        System.out.print("throws ");
                        for (int x = 0; x < exc.length; x++) { //循环输出每一方法所抛出的异常名字  
                            System.out.print(exc[x].getName());
                            if (x < (param.length - 1)) {
                                System.out.print(",");
                            }
                        }
                    }
                    System.out.println();
                }
                c = c.getSuperclass();
            } while (c != null);
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	@Test
    /*   根据某个对象的名称和方法去执行该方法 */
    public void test1() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException, Exception {   
        Class<? extends 反射> clazz = this.getClass();
        //根据名字获取方法
        Method m1=clazz.getDeclaredMethod("print");
        //打印方法名
        System.out.println("method name:"+m1.getName());
        //获取参数个数
        System.out.println("params count:"+m1.getParameterCount());
        //获取所有的注解，返回list
        System.out.println(m1.getAnnotations());
        //执行该方法，invoke
        System.out.println(m1.invoke(this, null));
    }
	
	public void print(){
		System.out.println("Print invoke");
	}
    
    @Test
    public void test2() throws Exception{
        Class<?> cl = Class.forName("in.java.lang.reflect.反射");
        Object obj=cl.newInstance();
        //1.获取 公有 无参方法 public void demo2.Person.public_prin()
        Method Person_public_prin=cl.getMethod("public_prin",null);
        System.out.println("获取执行 public void demo2.Person.public_prin() :");
        Person_public_prin.invoke(obj,null);
 
        //2.获取 公有 有参方法 public void demo2.Person.public_show(java.lang.String,int)
        Method Person_public_show=cl.getMethod("public_show",String.class,int.class);
        System.out.println("获取执行 public void demo2.Person.public_show(java.lang.String,int) :");
        Person_public_show.invoke(obj,"神奇的我",12);
 
        //3.获取 私有 无参方法 private void demo2.Person.private_prin()
        Method Person_private_prin=cl.getDeclaredMethod("private_prin",null);
        Person_private_prin.setAccessible(true);
        System.out.println("获取执行 private void demo2.Person.private_prin() :");
        Person_private_prin.invoke(obj,null);
		 
        //4.获取 私有 有参方法 private void demo2.Person.private_show(java.lang.String,int)
        Method Person_private_show=cl.getDeclaredMethod("private_show",String.class,int.class);
        Person_private_show.setAccessible(true);
        System.out.println("获取执行 private void demo2.Person.private_show(java.lang.String,int) :");
        Person_private_show.invoke(obj,"神奇的私有",23);        
    }	
	
    //公有 有参方法
    public void public_show(String str,int i) {
        System.out.println("public show "+str+"..."+i);
    }

    //公有 无参方法
    public void public_prin() {
        System.out.println("public prin");
    }

    //私有 有参方法
    private void private_show(String str,int i) {
        System.out.println("private show "+str+"..."+i);
    }

    //私有 无参方法
    private void private_prin() {
        System.out.println("private prin");
    }

}
