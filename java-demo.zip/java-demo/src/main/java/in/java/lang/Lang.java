package in.java.lang;

import java.lang.reflect.Method;
import java.lang.Integer;
import java.lang.String;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import org.testng.annotations.Test;

public class Lang {
	
	@Test
	public void string() {
		String.valueOf(11);//转换int为字符串
		String aaa="huangfucf1234";
		System.out.println("****String类方法：");
		System.out.println("aaa.length:"+aaa.length());
		System.out.println("aaa.isEmpty:"+aaa.isEmpty());
		System.out.println("aaa.indexOf:"+aaa.indexOf("a"));
		System.out.println("aaa.substring:"+aaa.substring(3));
		System.out.println("aaa.substring:"+aaa.substring(aaa.length()-4));
		System.out.println("aaa.substring:"+aaa.substring(4,5));
		System.out.println("aaa.substring:"+aaa.substring(3,4));
		System.out.println("aaa.substring:"+aaa.substring(0,5));
		System.out.println("aaa.concat:"+aaa.concat("bbb"));
		System.out.println("aaa.concat:"+aaa.concat("+contact"));
		System.out.println("aaa.contains："+aaa.contains("huang"));
		System.out.println("aaa.replace:"+aaa.replace("huang", "HUANG"));
		System.out.println("aaa.compare:"+aaa.compareTo("huangfucf1233"));
		System.out.println("aaa.compareToIgnoreCase:"+aaa.compareToIgnoreCase("HUANGFUcf1234"));
		System.out.println("aaa.equals:"+aaa.equals("huangfucf1234"));
	}
	
	@Test
	public static void string2(){
		System.out.println("****String静态方法：");
		System.out.println("String.valueOf:"+String.valueOf(11));
		String[] ar="hello".split("");
		System.out.println(Arrays.toString(ar));
		System.out.println(String.join("", ar));
		System.out.println(String.join("-", "test"));
		//String.copyValueOf(char[]);
		System.out.println("****String.format：");
		System.out.println(String.format("hi,%s", "Mr Wang"));
		System.out.println("String.format %s "+String.format("hi,%s", "Mr Wang"));//string.format 
		System.out.println("String.format:"+String.format("Hi,%s", "王力"));             
		System.out.println("String.format:"+String.format("Hi,%s:%s.%s", "王南","王力","王张"));                           
		System.out.printf("String.format:"+"字母a的大写是：%c %n", 'A'); //%n换行符
		System.out.printf("String.format:"+"3>7的结果是：%b %n", 3>7);  
		System.out.printf("String.format:"+"100的一半是：%d %n", 100/2);  
		System.out.printf("String.format:"+"100的16进制数是：%x %n", 100);  
		System.out.printf("String.format:"+"100的8进制数是：%o %n", 100);  
		System.out.printf("String.format:"+"50元的书打8.5折扣是：%f 元%n", 50*0.85);  
		System.out.printf("String.format:"+"上面价格的16进制数是：%a %n", 50*0.85);  
		System.out.printf("String.format:"+"上面价格的指数表示：%e %n", 50*0.85);  
		System.out.printf("String.format:"+"上面价格的指数和浮点数结果的长度较短的是：%g %n", 50*0.85);  
		System.out.printf("String.format:"+"上面的折扣是%d%% %n", 85);  
		System.out.printf("String.format:"+"字母A的散列码是：%h %n", 'A'); 
	    //$使用  
	    System.out.println("String.format:"+String.format("格式参数$的使用：%1$d,%2$s", 99,"abc"));                       
	    //+使用  
	    System.out.printf("String.format:"+"显示正负数的符号：%+d与%d%n", 99,-99);  
	    //补O使用  
	    System.out.printf("String.format:"+"最牛的编号是：%03d%n", 7);  
	    //空格使用  
	    System.out.printf("String.format:"+"Tab键的效果是：% 8d%n", 7);  
	    //.使用  
	    System.out.printf("String.format:"+"整数分组的效果是：%,d%n", 9989997);  
	    //空格和小数点后面个数  
	    System.out.printf("String.format:"+"一本书的价格是：% 50.5f元%n", 49.8);
	}
	
	@Test
	public  void date(){
		Date date=new Date();
		System.out.println("Current date time is:"+date); //Wed Oct 25 09:50:12 CST 2017
		Date date1=new Date();
		date.setTime(date1.getTime()+3*60*1000);
		System.err.println(date1); //Wed Oct 25 09:50:12 CST 2017
	    //Date格式化输出  
	    System.out.printf("全部日期和时间信息：%tc%n",date); //c的使用         	    
	    System.out.printf("年-月-日格式：%tF%n",date);  //f的使用  	    
	    System.out.printf("月/日/年格式：%tD%n",date);  //d的使用  	    
	    System.out.printf("HH:MM:SS PM格式（12时制）：%tr%n",date);  //r的使用  	    
	    System.out.printf("HH:MM:SS格式（24时制）：%tT%n",date);  //t的使用  	    
	    System.out.printf("HH:MM格式（24时制）：%tR",date);  	//R的使用      
	    //b的使用，月份简称  
	    System.out.println(String.format(Locale.US,"英文月份简称：%tb",date));                                                                              
	    System.out.printf("本地月份简称：%tb%n",date);  
	    //B的使用，月份全称  
	    System.out.println(String.format(Locale.US,"英文月份全称：%tB",date));  
	    System.out.printf("本地月份全称：%tB%n",date);  
	    //a的使用，星期简称  
	    System.out.println(String.format(Locale.US,"英文星期的简称：%ta",date));  
	    //A的使用，星期全称  
	    System.out.printf("本地星期的简称：%tA%n",date);  
	    //C的使用，年前两位  
	    System.out.printf("年的前两位数字（不足两位前面补0）：%tC%n",date);  
	    //y的使用，年后两位  
	    System.out.printf("年的后两位数字（不足两位前面补0）：%ty%n",date);  
	    //j的使用，一年的天数  
	    System.out.printf("一年中的天数（即年的第几天）：%tj%n",date);  
	    //m的使用，月份  
	    System.out.printf("两位数字的月份（不足两位前面补0）：%tm%n",date);  
	    //d的使用，日（二位，不够补零）  
	    System.out.printf("两位数字的日（不足两位前面补0）：%td%n",date);  
	    //e的使用，日（一位不补零）  
	    System.out.printf("月份的日（前面不补0）：%te",date);  
	    
	    //H的使用  
	    System.out.printf("2位数字24时制的小时（不足2位前面补0）:%tH%n", date);  
	    //I的使用  
	    System.out.printf("2位数字12时制的小时（不足2位前面补0）:%tI%n", date);  
	    //k的使用  
	    System.out.printf("2位数字24时制的小时（前面不补0）:%tk%n", date);  
	    //l的使用  
	    System.out.printf("2位数字12时制的小时（前面不补0）:%tl%n", date);  
	    //M的使用  
	    System.out.printf("2位数字的分钟（不足2位前面补0）:%tM%n", date);  
	    //S的使用  
	    System.out.printf("2位数字的秒（不足2位前面补0）:%tS%n", date);  
	    //L的使用  
	    System.out.printf("3位数字的毫秒（不足3位前面补0）:%tL%n", date);  
	    //N的使用  
	    System.out.printf("9位数字的毫秒数（不足9位前面补0）:%tN%n", date);  
	    //p的使用  
	    String str3 = String.format(Locale.US, "小写字母的上午或下午标记(英)：%tp", date);  
	    System.out.println(str3);   
	    System.out.printf("小写字母的上午或下午标记（中）：%tp%n", date);  
	    //z的使用  
	    System.out.printf("相对于GMT的RFC822时区的偏移量:%tz%n", date);  
	    //Z的使用  
	    System.out.printf("时区缩写字符串:%tZ%n", date);  
	    //s的使用  
	    System.out.printf("1970-1-1 00:00:00 到现在所经过的秒数：%ts%n", date);  
	    //Q的使用  
	    System.out.printf("1970-1-1 00:00:00 到现在所经过的毫秒数：%tQ%n", date);
	}
	
	@Test
	public void float方法(){
		
	}
	
	@Test
	public static void float静态方法(){
		System.out.println(Float.MAX_VALUE);
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.SIZE);
		//比较大小
		Float.compare(1L, 2L);
		
	}
	
	@Test
	public void integer方法(){
		Integer.getInteger("1").toString();
		//InputStream
	}
	
	@Test
	public static void integer静态方法(){
		//转化为10进制
		Integer.toBinaryString(10);
		//返回Integer最大值、最小值
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		System.out.println("##compare2,1: "+Integer.compare(2,1));
		System.out.println("##compare1,2: "+Integer.compare(1,2));
		//String转换喂int
		int a=Integer.parseInt("3"); //string转int
		int b=Integer.valueOf("3"); //string转int
		System.out.println("##parseInt:"+a);
		System.out.println("##valueOf:"+b);
		//int转换为String
		int i =11;
		System.out.println("##toString:"+Integer.toString(i));
		//比较大小	
		System.out.println("##Compare:"+Integer.compare(1, 2));
		//进制转换
		//十进制转成十六进制：
		Integer.toHexString(11);
		//十进制转成八进制
		Integer.toOctalString(12);
		//十进制转成二进制
		Integer.toBinaryString(13);
		//十六进制转成十进制
		Integer.valueOf("FFFF",16).toString();
		//八进制转成十进制
		Integer.valueOf("876",8).toString();
		//二进制转十进制
		Integer.valueOf("0101",2).toString();		
	}
	
	@Test
	public void math(){
		System.out.println(Math.round(11.5f));
		System.out.println(Math.round(-11.5));
		System.out.println(Math.round(0.5));
		System.out.println(Math.round(-0.5));
	}
	
	@Test
	public  void method() {
		Method.class.getName();
		Method.class.getAnnotations();
	}

	
	@Test
	public void stringBuffer(){
//		====================================
//		在线程安全上，StringBuilder是线程不安全的，而StringBuffer是线程安全的
		StringBuffer sb = new StringBuffer("huangfu");
		sb.append("chunfeng");
		sb.indexOf("h");
		sb.insert(0, "hello");
		System.out.println("insert:"+sb);
		sb.replace(0, 5, "world");
		System.out.println("replace:"+sb);
		sb.reverse();
		System.out.println("reverse:"+sb);
		System.out.println("substring10:"+sb.substring(0,10));
		System.out.println("substring5:"+sb.substring(5));
	}

	@Test
	public void stringBuilder(){
		
	}
	
	@Test
	public  void system(){
		System.out.println();
		System.err.println();
		System.gc();		
		//系统变量		
		Map<String,String> env=System.getenv();
		for (Map.Entry<String,String> entry:env.entrySet()) {
			System.out.println("Environment key:"+entry.getKey()+" value:"+entry.getValue());
		}
		//系统属性
		Map<Object, Object> properties=System.getProperties();
		for (Entry<Object, Object> propertyEntry:properties.entrySet()){
			System.out.println("Properties key:"+propertyEntry.getKey().toString()+" value:"+propertyEntry.getValue().toString());
		}
	}
	
	
	/**
	 * 
	 * 
	USERPROFILE        ：用户目录
	USERDNSDOMAIN      ：用户域
	PATHEXT            ：可执行后缀
	JAVA_HOME          ：Java安装目录
	TEMP               ：用户临时文件目录
	SystemDrive        ：系统盘符
	ProgramFiles       ：默认程序目录
	USERDOMAIN         ：帐户的域的名称
	ALLUSERSPROFILE    ：用户公共目录
	SESSIONNAME        ：Session名称
	TMP                ：临时目录
	Path               ：path环境变量
	CLASSPATH          ：classpath环境变量
	PROCESSOR_ARCHITECTURE ：处理器体系结构
	OS                     ：操作系统类型
	PROCESSOR_LEVEL    ：处理级别
	COMPUTERNAME       ：计算机名
	Windir             ：系统安装目录
	SystemRoot         ：系统启动目录
	USERNAME           ：用户名
	ComSpec            ：命令行解释器可执行程序的准确路径
	APPDATA            ：应用程序数据目录	
	 * 
	 * 属性
	java.version Java ：运行时环境版本
	java.vendor Java ：运行时环境供应商
	java.vendor.url ：Java供应商的 URL
	java.home &nbsp;&nbsp;：Java安装目录
	java.vm.specification.version： Java虚拟机规范版本
	java.vm.specification.vendor ：Java虚拟机规范供应商
	java.vm.specification.name &nbsp; ：Java虚拟机规范名称
	java.vm.version ：Java虚拟机实现版本
	java.vm.vendor ：Java虚拟机实现供应商
	java.vm.name&nbsp; ：Java虚拟机实现名称
	java.specification.version：Java运行时环境规范版本
	java.specification.vendor：Java运行时环境规范供应商
	java.specification.name ：Java运行时环境规范名称
	java.class.version ：Java类格式版本号
	java.class.path ：Java类路径
	java.library.path  ：加载库时搜索的路径列表
	java.io.tmpdir  ：默认的临时文件路径
	java.compiler  ：要使用的 JIT编译器的名称
	java.ext.dirs ：一个或多个扩展目录的路径
	os.name ：操作系统的名称
	os.arch  ：操作系统的架构
	os.version  ：操作系统的版本
	file.separator ：文件分隔符
	path.separator ：路径分隔符
	line.separator ：行分隔符
	user.name ：用户的账户名称
	user.home ：用户的主目录
	user.dir：用户的当前工作目录
	*/	
}
