package in.java.lang.reflect;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.testng.annotations.Test;


public class 动态代理 {
	
	//cglib方式动态代理
	@Test
	public static void main(String args[]){
        InterCeptorHandler interCeptorHandler = new InterCeptorHandler();
        StudentServiceImpl2 studentServiceImpl2 = (StudentServiceImpl2) interCeptorHandler.getProxy(StudentServiceImpl2.class);
        System.out.println("*Start to create:");
        Student student = studentServiceImpl2.createStudent("李胜涛",22);
        System.out.println("*Name:"+student.getName());
        System.out.println("*Age:"+student.getAge());
	}
	
}
