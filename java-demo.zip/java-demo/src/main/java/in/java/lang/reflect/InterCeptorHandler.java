package in.java.lang.reflect;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

class InterCeptorHandler implements MethodInterceptor{
	 
    public Object getProxy(Class<?> clazz){
        Enhancer enhancer = new Enhancer();
        //设置代理目标
        enhancer.setSuperclass(clazz);
        //设置回调方法 设置单一回调对象，在调用中拦截对目标方法的调用
        enhancer.setCallback(this);
//		//设置类加载器
//		enhancer.setClassLoader(clazz.getClassLoader());        
        return enhancer.create();
    }
 
	/**
	 * 
	 * 方法描述 当对基于代理的方法回调时，在调用原方法之前会调用该方法
	 * 拦截对目标方法的调用
	 *
	 * @param obj 代理对象
	 * @param method 拦截的方法
	 * @param args 拦截的方法的参数
	 * @param proxy 代理
	 * @return
	 * @throws Throwable
	 */
    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
        //切记不要使用 method.invoke(o,objects) 和 methodProxy.invoke(o, args); 否则会死循环
    	//原因：因为method.invoke调用的就是intercept方法，所以自己调用自己，就会进入死循环。
    	System.out.println("intercept执行开始:");
        try {
        	System.out.println(o.toString());
        } catch (Exception e){
        	Thread.sleep(6000000);
        }
        Object o1 = methodProxy.invokeSuper(o,objects);
        System.out.println("intercept执行结束:");
        return o1;
    }
}
