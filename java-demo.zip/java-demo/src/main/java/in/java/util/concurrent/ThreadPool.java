package in.java.util.concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class ThreadPool {
	
	public static class TestRunnable extends Thread {
		
		@Override
		public void run(){
			System.out.println(Thread.currentThread().getName());
		}
	}

	//	Executors创建线程池便捷方法列表：
	//	方法名	功能
	//	newFixedThreadPool(int nThreads)	创建固定大小的线程池
	//	newSingleThreadExecutor()	创建只有一个线程的线程池
	//	newCachedThreadPool()	创建一个不限线程数上限的线程池，任何提交的任务都将立即执行
	//	newScheduledThreadPool创建一个大小无限的线程池。此线程池支持定时以及周期性执行任务的需求。
	public static void main(String args[]) {
		//固定线程数大小线程池
		ExecutorService executorService=Executors.newFixedThreadPool(20);
		for (int i=0;i<=20;i++) {
			executorService.execute(new TestRunnable());
			System.out.println("====");
		}
		//是否关闭
		System.out.println(executorService.isTerminated());
		//关闭线程池
		executorService.shutdown();
		System.out.println("isTerminated:"+executorService.isTerminated());

	}

	//	小程序使用这些快捷方法没什么问题，对于服务端需要长期运行的程序，创建线程池应该直接使用ThreadPoolExecutor的构造方法。没错，上述Executors方法创建的线程池就是ThreadPoolExecutor。		
	//		Java线程池的完整构造函数
	//	int corePoolSize, // 线程池长期维持的线程数，即使线程处于Idle状态，也不会回收。
	//	int maximumPoolSize, // 线程数的上限
	//	long keepAliveTime, // 超过corePoolSize的线程的idle时长，
	//	TimeUnit unit, // 超过这个时间，多余的线程会被回收。
	//	BlockingQueue<Runnable> workQueue, // 任务的排队队列
	//	ThreadFactory threadFactory, // 新线程的产生方式
	//	RejectedExecutionHandler handler) // 拒绝策略
	//	竟然有7个参数，很无奈，构造一个线程池确实需要这么多参数。这些参数中，比较容易引起问题的有corePoolSize, maximumPoolSize, workQueue以及handler：
	//	corePoolSize和maximumPoolSize设置不当会影响效率，甚至耗尽线程；
	//	workQueue设置不当容易导致OOM；
	//	handler设置不当会导致提交任务时抛出异常。
	//	正确的参数设置方式会在下文给出。		
	public void test(){
		//ThreadPoolExecutor tp =new ThreadPoolExecutor().;
	}
	
}
