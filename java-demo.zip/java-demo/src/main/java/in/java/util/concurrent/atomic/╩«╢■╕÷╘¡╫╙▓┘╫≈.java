package in.java.util.concurrent.atomic;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

import org.testng.annotations.Test;

public class 十二个原子操作 {
	//1.原子更新基本类型类
	//AtomicBoolean：原子更新布尔类型。
	//AtomicInteger：原子更新整型。
	//AtomicLong：原子更新长整型。
//	2.原子更新数组
//	AtomicIntegerArray：原子更新整型数组里的元素。
//	AtomicLongArray：原子更新长整型数组里的元素。
//	AtomicReferenceArray：原子更新引用类型数组里的元素。
//	3.原子更新引用类型
//	AtomicReference：原子更新引用类型。
//	AtomicReferenceFieldUpdater：原子更新引用类型里的字段。
//	AtomicMarkableReference：原子更新带有标记位的引用类型。
//	4.原子更新属性（字段）类
//	AtomicIntegerFieldUpdater：原子更新整型的字段的更新器。
//	AtomicLongFieldUpdater：原子更新长整型字段的更新器。
//	AtomicStampedReference：原子更新带有版本号的引用类型。	
	static AtomicInteger ai = new AtomicInteger(1);
	static int[] value = new int[]{1, 2};
	static AtomicIntegerArray aia = new AtomicIntegerArray(value);
	
	
	@Test
	public void 更新基本类型(){
		
	}
	
	@Test
	public void 更新数组(){
		
	}
	
	@Test
	public void 更新引用类型(){
		
	}
	
	@Test
	public void 更新属性字段(){
		
	}
}
