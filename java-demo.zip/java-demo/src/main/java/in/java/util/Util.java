package in.java.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Stack;
import java.util.UUID;
import java.util.Map.Entry;
import org.testng.annotations.Test;

public class Util {
	
    class SortByAge implements Comparator<Object> {
    	@Override
    	public int compare(Object o1, Object o2) {
    		Integer.parseInt(o2.toString());
    		Integer.parseInt(o1.toString());
    		return Integer.compare(Integer.parseInt(o1.toString()),Integer.parseInt(o2.toString()));
    	}
    }
	
	public void abstractList() {
		//**抽象类 AbstractList
		//java.util.AbstractList<String> abs = new java.util.AbstractList<String>();
	}

	
	@Test
	public static void arrays静态方法() {
		//数组转化为list，转换为字符串为列表
		List<String> str = Arrays.asList("UNICORN".split(""));
		System.out.println(str.toString());
		int[] arr0 = new int[5];
		Arrays.fill(arr0, 2);
		System.out.println("填充数组:"+Arrays.toString(arr0));
		int[] arr1 = {3,2,1,5,4};
		//串行排序
		Arrays.sort(arr1);
		System.out.println("排序:"+Arrays.toString(arr1));
		Arrays.sort(arr1,2,4);
		System.out.println("排序:"+Arrays.toString(arr1));
		//并行排序，性能优于串行排序
		Arrays.parallelSort(arr1);
		System.out.println("是否相等:"+Arrays.equals(arr0,arr1));
		//拷贝数组
		System.out.println("拷贝数组:"+Arrays.toString(Arrays.copyOf(arr1, 3)));
		//拷贝数组2
		System.out.println("拷贝数组2:"+Arrays.toString(Arrays.copyOfRange(arr1, 2, 5)));
		int []arr3 = {10,20,30,40,50};
		System.out.println("二分法查找:"+Arrays.binarySearch(arr3, 20));
		System.out.println("二分法查找:"+Arrays.binarySearch(arr3, 0,3,30));
	}
	
	@Test
	public  void arrayList() {
		//普通类 ArrayList
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("1");
		arrayList.add("2");
		arrayList.add("3");
		arrayList.get(0);//获取元素
		arrayList.set(0, "hello");//设置元素
		arrayList.remove(0);//删除元素
		arrayList.contains("2");
		arrayList.isEmpty();
		arrayList.iterator();
		arrayList.size();
		arrayList.subList(0, 1);
		arrayList.sort(new SortByAge());
		for(String num:arrayList){
			System.out.println(num);
		}

		//遍历1
		System.out.println("遍历:");
		for (String row:arrayList){
			System.out.println(row);
		}
		//遍历2
		for(int i=0;i<arrayList.size();i++){
			System.out.println(arrayList.get(i));
		}
		//遍历3
		Iterator<String> it=arrayList.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
//		//初始化赋值
//		@SuppressWarnings("serial")
//		ArrayList<String> list = new ArrayList<String>() {{ 
//			add( "first" ); 
//			add( "second" ); 
//			add( "third" ); 
//		}};
//		list.add(0, "zero");
		
		//输出feng chun fu huang
		String aaa="huang fu chun feng";
		String[] bbb=aaa.split(" ");
		String[] result1 = new String[bbb.length];
		String result2 = "";
		System.out.println(Arrays.toString(bbb));
		for (int i=bbb.length-1;i>=0;i--) {
			//Arrays.fill(ccc,bbb[i]);
			result1[bbb.length-1-i]=bbb[i];
			result2=result2+bbb[i]+" ";
		}
		System.out.println("倒序字符串："+Arrays.toString(result1));
		System.out.println("倒序字符串："+result2);
		
		//把字符串倒序排列返回
		StringBuffer sb = new StringBuffer("huangfu");
		System.out.println("倒序排列："+sb.reverse().toString());
	}	
	
	@Test
	public void arrayDeque() {
		//普通类 ArrayDeque
		/* ArrayDeque不是线程安全的。 
		 * ArrayDeque不可以存取null元素，因为系统根据某个位置是否为null来判断元素的存在。 
		 * 当作为栈使用时，性能比Stack好；当作为队列使用时，性能比LinkedList好。 
		 */
		java.util.ArrayDeque<String> arrayDeque = new ArrayDeque<String>();
		arrayDeque.add("");
		arrayDeque.addFirst("");//在数组前面添加元素
		arrayDeque.addLast("");//在数组后面添加元素
		arrayDeque.offerFirst("");// 在数组前面添加元素，并返回是否添加成功
		arrayDeque.offerLast("") ;//在数组后天添加元素，并返回是否添加成功
		arrayDeque.getFirst();
		arrayDeque.getLast();
	}
	
	
	@Test
	public  void calender(){
		Calendar now = Calendar.getInstance();
        System.out.println("年: " + now.get(Calendar.YEAR));  
        System.out.println("月: " + (now.get(Calendar.MONTH) + 1) + "");  
        System.out.println("日: " + now.get(Calendar.DAY_OF_MONTH));  
        System.out.println("时: " + now.get(Calendar.HOUR_OF_DAY));  
        System.out.println("分: " + now.get(Calendar.MINUTE));  
        System.out.println("秒: " + now.get(Calendar.SECOND));  
        System.out.println("当前时间毫秒数：" + now.getTimeInMillis());  
        System.out.println(now.getTime());
	}
	
	/**
	 * <h1>等待到几分钟后，如现在为10:42，传1表示等待到10:43</h1>
	 * <p>例：20180116</p>
	 * @author huangfucf
	 * @param minute
	 * @throws InterruptedException 
	 * 
	 */
	@Test
	public  void calenderWaitMinute(int minute) throws InterruptedException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar waitTime = Calendar.getInstance();
		waitTime.add(Calendar.MINUTE, minute);
		String wait=sdf.format(waitTime.getTime());
		System.out.println(wait);
		//等待时间
		while (true) {
			Thread.sleep(1000);
			Calendar nowTime = Calendar.getInstance();
			String now=sdf.format(nowTime.getTime());
			System.out.println(now);
			if (wait.equals(now)) {
				break;
			}
		}
	}
	
	@Test
	public static void collections静态方法(){
		ArrayList<String> list=new ArrayList<String>();
		list.add(0,"1");
		list.add(0,"2");
		System.out.println(Collections.frequency(list, "2"));
	}
	
	@Test
	public void hashSet() {
		ArrayList<String> list=new ArrayList<String>();
		list.add("1");
		list.add("1");
		list.add("2");
		//String[] str=new String[]{"shanghai","hangzhou","jilin"};
		HashSet<String> set=new HashSet<String>();
		set.add("mate1");//添加元素
		set.addAll(list);//批量添加
		set.remove(1);//删除元素
		System.out.println("addAll:"+set.toString());
		System.out.println("delete:"+set.toString());
		System.out.println("contain:"+set.contains("mate1"));//是否包含元素
		System.out.println("size:"+set.size());//返回set元素个数
		
		//list转化为set
		//HashSet<String> set=new HashSet<String>(list); 
		//set转化为list
		//ArrayList<String> list1=new ArrayList<String>(set);
		//array转set
//		String[] array=new String[]{"a","b","c","d","e"};
//		HashSet<String> arraySet = new HashSet<>(Arrays.asList(array));
		//set转array
		String[] arrSet=(String[]) set.toArray();
		System.out.println("toArray:"+Arrays.toString(arrSet));
	}
	
	
	@Test
	public  void hashMap() {
		HashMap<String,String> map=new HashMap<String,String>();
		map.put("key1", "value1");
		map.put("key1", "new");
		map.put("key2", "value2");
		map.put("key3", "value3");
		map.get("key1");//获取key的值
		map.isEmpty();//判断是否为空
		map.size();//长度
		map.remove("key3");//删除某个key以及value
		map.containsKey("key3");//是否包含key
		map.containsValue("value3");//是否包含某个value
		//遍历的四种方法
		map.values();
		map.keySet();
		map.entrySet();
		map.entrySet().iterator();
	}	
	
	@Test
	public void hashTable(){
		Hashtable<String,String> table=new Hashtable<String,String>();
		table.put("1", "a");
		table.put("2", "b");
		table.put("1", "1");
		table.put("3", "c");//添加值
		System.out.println(table.toString());
		System.out.println("get:"+table.get("1"));//获取值
		System.out.println("containsKey:"+table.containsKey("1"));//是否包含key
		System.out.println("containsValue:"+table.containsValue("aa"));//是否包含value
		System.out.println("isEmpty:"+table.isEmpty());//是否为空
		System.out.println("size:"+table.size());//返回个数
		System.out.println("replace:"+table.replace("3", "55"));//替换并返回字符串
		System.out.println(table.toString());
	}
	
	public  void iterator(){
		
	}
	
	@Test
	public void linkedList(){
//		值得注意的是LinkedList类实现了Queue接口，因此我们可以把LinkedList当成Queue来用
//		Queue使用时要尽量避免Collection的add()和remove()方法，而是要使用offer()来加入元素，使用poll()来获取并移出元素。
//		它们的优点是通过返回值可以判断成功与否，add()和remove()方法在失败的时候会抛出异常。 如果要使用前端而不移出该元素，使用
//		element()或者peek()方法。
//		add();向链表末尾添加对象。
//		addFirst（）在链表开头添加对象。
//		addLast（）在链表末尾添加对象。
//		getFirst（）得到链表开头的对象。
//		getLast（）得到链表末尾的对象。		
		LinkedList<String> list=new LinkedList<String>();
		list.add("");
	}	
	
	public  void properties() throws IOException {
		String path = "D:/dubbo.properties";
		Util ur=new Util();
		InputStream is = ur.getClass().getClassLoader().getResourceAsStream(path);
		Properties properties = new Properties();
		properties.load(is);
		properties.get("key1");
		properties.getProperty("key2", "default");
	}
	
	@Test
	public void stack(){
		Stack<Integer> st=new Stack<Integer>();
		st.add(1);
		st.add(2);
		st.add(2);
		st.add(4);
		System.out.println(st.toString());
		//peek只是获取栈顶的值，但是不会把元素从栈顶取出
		System.out.println(st.peek());
		System.out.println(st.toString());
		//pop会取出栈顶的元素
		System.out.println(st.pop());
		System.out.println(st.toString());
		System.out.println("isEmpty:"+st.isEmpty());
		System.out.println("search 1:"+st.search(1));
		System.out.println("search 5:"+st.search(5));
	}
	
	@Test
	public void set(){
		//set是一个不包含重复元素的collection
		Set<Object> set=new HashSet<Object>();
		set.add("john");
		set.add("john");
		System.out.println(set.size());
		
		//在set中加入list，去除重复元素
		List<String> list = new ArrayList<String>();
		list.add("helen");
		list.add("kitty");
		set.add(list);
		System.out.println(set.size());
		System.out.println(set.toString());
	}
	
	public  void uuid() {
		System.out.println(UUID.randomUUID().toString());
	}
	
	public  void vector() {
		
	}
}
