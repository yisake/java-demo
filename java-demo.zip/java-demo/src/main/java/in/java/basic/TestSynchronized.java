package in.java.basic;

public class TestSynchronized {

	//对象锁
	//非静态方法使用 synchronized 修饰的写法，修饰实例方法时，锁定的是当前对象：
	public synchronized void minus() {
	    int count = 5;
	    for (int i = 0; i < 5; i++) {
	        count--;
	        System.out.println(Thread.currentThread().getName() + " - " + count);
	        try {
	            Thread.sleep(500);
	        } catch (InterruptedException e) {
	        }
	    }
	}
	
	//对象锁
	public synchronized void minus2() {
	    int count = 5;
	    for (int i = 0; i < 5; i++) {
	        count--;
	        System.out.println(Thread.currentThread().getName() + " - " + count);
	        try {
	            Thread.sleep(500);
	        } catch (InterruptedException e) {
	        }
	    }
	}
	
	//不带锁，示例
	public void minus3() {
	    int count = 5;
	    for (int i = 0; i < 5; i++) {
	        count--;
	        System.out.println(Thread.currentThread().getName() + " - " + count);
	        try {
	            Thread.sleep(500);
	        } catch (InterruptedException e) {
	        }
	    }
	}
	
	//类锁
	public static synchronized void minus4() {
	    int count = 5;
	    for (int i = 0; i < 5; i++) {
	        count--;
	        System.out.println(Thread.currentThread().getName() + " - " + count);
	        try {
	            Thread.sleep(500);
	        } catch (InterruptedException e) {
	        }
	    }
	}
}

