package in.java.basic;

public class synchronized关键字 implements Runnable{
	private int count=0;
	@Override
	public void run() {
		domore();
	}
	
	//修饰一个代码块
	public void domore() {
		synchronized(this) {
			for(int i=0;i<50;i++)
				System.out.println(Thread.currentThread().getName()+":"+(count++));
		}
	}
	
	public static void main(String[] args) {
		String choice="1";
		if (choice.equals("1")){
			test1();
		}else if(choice.equals("2")) {
			test2();
		}
		//test2();
	}
	
	//
	public static void test1(){
		System.out.println("example1");
        synchronized关键字 myrunnable=new synchronized关键字();
        Thread thread1=new Thread(myrunnable,"Thread1");
        Thread thread2=new Thread(myrunnable,"Thread2");
        thread1.start();
        thread2.start();
	}
	
	//这是因为synchronized只锁定对象，每个对象只有一个锁（lock）与之相关联
/*	这时创建了两个SyncThread的对象syncThread1和syncThread2，线程thread1执行的是syncThread1对象中的synchronized代码(run)，而线程thread2执行的是syncThread2对象中的synchronized代码(run)；我们知道synchronized锁定的是对象，这时会有两把锁分别锁定syncThread1对象和syncThread2对象，而这两把锁是互不干扰的，不形成互斥，所以两个线程可以同时执行。
	————————————————
	版权声明：本文为CSDN博主「奔跑的蜗牛蒋」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
	原文链接：https://blog.csdn.net/xhjj520/article/details/79739442	
*/	public static void test2(){
		System.out.println("example2");
        synchronized关键字 myrunnable=new synchronized关键字();
        synchronized关键字 myrunnable1=new synchronized关键字();
        Thread thread1=new Thread(myrunnable,"Thread1");
        Thread thread2=new Thread(myrunnable1,"Thread2");
        thread1.start();
        thread2.start();
	}

	
}
