package in.java.basic;

public class TestSynchronizedRun {
	
	public static void main(String args[]){
		//test();
		//test1();
		//test2();
		//test3();
		test4();
	}
	
	//对象锁
	//可以看到，某个线程得到了对象锁之后，该对象的其他同步方法是锁定的，其他线程是无法访问的。 
    public static void test() {
        final TestSynchronized test = new TestSynchronized();
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                test.minus();
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                test.minus();
            }
        });
        thread1.start();
        thread2.start();
    }
	
    //对象锁
    public static  void test1() {
        final TestSynchronized test = new TestSynchronized();
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                test.minus();//线程同步方法
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                test.minus2();//线程同步方法
            }
        });
        thread1.start();
        thread2.start();
    }
    
    //对象锁
    //可以看到，结果是交替的，说明线程是交替执行的，说明如果某个线程得到了对象锁，
    //但是另一个线程还是可以访问没有进行同步的方法或者代码。
    //进行了同步的方法（加锁方法）和没有进行同步的方法（普通方法）是互不影响的，
    //一个线程进入了同步方法，得到了对象锁，其他线程还是可以访问那些没有同步的方法（普通方法）。
    //当获取到与对象关联的内置锁时，并不能阻止其他线程访问该对象，
    //当某个线程获得对象的锁之后，只能阻止其他线程获得同一个锁。
    public static  void test2() {
        final TestSynchronized test = new TestSynchronized();
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                test.minus();//线程同步方法
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                test.minus3();//非线程同步方法
            }
        });
        thread1.start();
        thread2.start();
    }	
	
    //类锁
    //类锁需要 synchronized 来修饰静态 static 方法，写法如下：
    //public static synchronized void test(){
    //}
    public static void test3(){
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                TestSynchronized.minus4();
            }
        });

        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                TestSynchronized.minus4();
            }
        });
        thread1.start();
        thread2.start();
    }
    
    //可以看到两个线程是交替进行的，也就是说类锁和对象锁是不一样的锁，是互相独立的。
    public static void test4(){
    	TestSynchronized test = new TestSynchronized();
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                TestSynchronized.minus4();//静态方法加锁
            }
        });

        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                test.minus2();
            }
        });
        thread1.start();
        thread2.start();
    }
}

