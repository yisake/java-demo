package in.java.basic;

import org.testng.annotations.Test;

public class java代理模式 {
	
	public interface IUpdatable {
		  void update();
	}
	
	public class UpdatableImpl implements IUpdatable {
		  @Override
		  public void update() {
		    System.out.println("update UpdatableImpl.");
		  }
	}	
	
	public class UpdatableProxy implements IUpdatable {
		  private IUpdatable updatable;

		  public UpdatableProxy(IUpdatable updatable) {
		    this.updatable = updatable;
		  }

		  @Override
		  public void update() {
		    System.out.println("pre safety check.");
		    updatable.update();
		    System.out.println("after safety check.");
		  }
	}
	
	  @Test
	  public void testStaticProxy() {
	    IUpdatable updatable = new UpdatableImpl();
	    IUpdatable proxy = new UpdatableProxy(updatable);
	    proxy.update();
	  }
}
