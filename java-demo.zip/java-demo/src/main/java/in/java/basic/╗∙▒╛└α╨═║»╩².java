package in.java.basic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.testng.annotations.Test;

public class 基本类型函数 {
	
	//	java有8中基础数据类型，分为四类
	//	1.整形 byte,short,int,long
	//	2.浮点型 float,double
	//	3.布尔型 boolean
	//	4.字符型 char
	//  数组不是基本数据类型，验证方法System.out.println(new int[2] instanceof Object);
	@Test
	public void 基本类型(){
		int a=111;
		short b=1111;
		long c=1111;
		byte d=(byte) 1111;
	//		float e=0.11;
	//		double f=;
		boolean g=true;
		char h='e';
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(g);
		System.out.println(h);
	}
	
	@Test
	public void 数组(){
		int[] a1= new int[3]; //数组初始化 定长不赋值
		int[] a2= {4,5,6};//初始化定长并且赋值
		int[] a3= new int[]{1,2,3};//初始化不定长赋值
		System.out.println(Arrays.toString(a1));
		System.out.println(Arrays.toString(a2));
		System.out.println(Arrays.toString(a3));
	}

	@Test
	public void 列表个数(){
		ArrayList<String> list=new ArrayList<String>();
		list.add("1");
		list.add("1");
		list.add("2");
		HashMap<String, Integer> map=new HashMap<String, Integer>();
		for (int i=0;i<list.size();i++) {
			if (!map.containsKey(list.get(i))){
				map.put(list.get(i), 0);
			}
			map.put(list.get(i),map.get(list.get(i))+1);
		}
		for (Entry<String, Integer> entry:map.entrySet()){
			System.out.println("key:"+entry.getKey()+"value:"+entry.getValue());
		}
	}
	
	@Test
	public void instanceof关键字(){
//		1、instanceOf关键字，用来判断对象是否是类的实例
//		2、isAssignableFrom，用来判断类型间是否存在派生关系
//		3、isInstance方法，用来判断对象是否属于某个类型的实例		
		A a = new A();
		B b = new B();
		A ba = new B();
		System.out.println("1------------");
		System.out.println(b instanceof B);
		System.out.println(b instanceof A);
		System.out.println(b instanceof Object);
		System.out.println(null instanceof Object);
		System.out.println("2------------");
		System.out.println(b.getClass().isInstance(b));
		System.out.println(b.getClass().isInstance(a));
		System.out.println("3------------");
		System.out.println(a.getClass().isInstance(ba));
		System.out.println(b.getClass().isInstance(ba));
		System.out.println(b.getClass().isInstance(null));
		System.out.println("4------------");
		System.out.println(A.class.isInstance(a));
		System.out.println(A.class.isInstance(b));
		System.out.println(A.class.isInstance(ba));
		System.out.println("5------------");
		System.out.println(B.class.isInstance(a));
		System.out.println(B.class.isInstance(b));
		System.out.println(B.class.isInstance(ba));
		System.out.println("6------------");
		System.out.println(Object.class.isInstance(b));
		System.out.println(Object.class.isInstance(null));
	}

	
	@Test
	public void class关键字(){
		System.out.println(this.getClass().getResource("/").getPath());
		//得到的是当前类FileTest.class文件的URI目录。不包括自己！
		System.out.println(this.getClass().getResource(""));
		System.out.println(this.getClass().getClassLoader().getResource(""));
		System.out.println(ClassLoader.getSystemResource(""));
		//获取当前的包名  		
		System.out.println(this.getClass().getPackage().getName());
		System.out.println();
	}
	
	class A {
	}

	class B extends A {
	}
}
