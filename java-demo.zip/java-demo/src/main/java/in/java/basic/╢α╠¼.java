package in.java.basic;

public class 多态 {
	
    public static void main(String[] args) {
        Animal a=new Animal();
        a.shout();
        Dog b=new Dog();
        b.shout();
        //向上可以自动转换类型，由子类转换成父类！
        Animal b1=new Dog();    
        b1.shout();
        //向下（由父类转换成子类）强制类型转换！以调用该对象特有的方法！
        Dog b2=(Dog)b1;    
        b2.seeDoor();
        //调用该对象特有的方法
        Animal c=new Cat();
        animalCry(c);
    }
    
    static void animalCry(Animal a1) {
        a1.shout();
    }
}


class Animal{
    public void shout() {
        System.out.println("叫！");
        
    }
}

class Dog extends Animal{
    public void shout() {
        System.out.println("汪汪");
    }
    public void seeDoor() {
        System.out.println("看门");    //该对象特有的方法！
    }
}

class Cat extends Animal{
    public void shout() {
        System.out.println("喵喵");
    }
}
