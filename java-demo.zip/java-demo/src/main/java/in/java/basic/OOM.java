package in.java.basic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class OOM {
	static class Key{
		Integer id;
		Key(Integer id){
			this.id=id;
		}
		
		@Override
		public int hashCode(){
			return id.hashCode();
		}
	}
	
	static class OOMObject{
		
	}	
	
	public static void main(String args[]) throws Exception{

		List<OOMObject> list = new ArrayList<OOMObject>();
		int i=0;
		while(true){
			System.out.println(i++);
			//Thread.sleep(10);
			list.add(new OOMObject());
		}
		
//		HashMap m=new HashMap();
//		while(true){
//			for (int i=0;i<1000;i++){
//				if (m.containsKey(i)){
//					m.put(new Key(i), "Number:"+i);
//				}
//			}
//		}
	}
}
