package in.java.basic;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import org.testng.annotations.Test;

public class Class方法 {
	//声明不同作作用域变量
    private String name;
    protected String age;
    public String school;
    
    public void 普通方法(String name,int age){
    	System.out.println(this.name);
    	System.out.println(this.age);
    	System.out.println(name+age);
    }
    
    public static void 静态方法(String str){
    	
    }
    
    //.class方法：当你要获得一个类的Class对象时（作函数参数的时候），
    //你不能调用getClass方法，那你只能用类名.class来达到效果
    //getClass方法：该方法只能由类的实例变量调用
	@Test
    public void test(){
    	Class<?> cls=new Class方法().getClass();
    	cls.getConstructors();
    	//获取类名
    	System.out.println("**getName:"+cls.getName());
    	//获取所有方法名，返回所有方法的数组
    	System.out.println("**getMethods:");
    	for(Method method:cls.getMethods()){
    		//获取方法名
    		System.out.println(method.getName());
    		//获取方法参数，返回Parameter数组
    		System.out.println(Arrays.toString(method.getParameters()));
    		//获取方法注解
    		method.getAnnotations();
    		method.getDeclaredAnnotations();
    		//获取方法返回类型
    		method.getReturnType();
    	}
    	//获取
    	System.out.println("**getModifiers:"+cls.getModifiers());
    	//获取
    	System.out.println("**getSimpleName:"+cls.getSimpleName());
    	//获取类的包名
    	System.out.println("**getPackage:"+cls.getPackage().getName());
    	//返回是否是一个类的实例化对象
    	System.out.println("**isItance:"+cls.isInstance(Class方法.class));
    	//getFields()：获得某个类的所有的公共（public）的字段，包括父类中的字段。 
    	//getDeclaredFields()：获得某个类的所有声明的字段，即包括public、private和proteced，但是不包括父类的申明字段。
    	//同样类似的还有getConstructors()和getDeclaredConstructors()、getMethods()和getDeclaredMethods()，这两者分别表示获取某个类的方法、构造函数。
    	System.out.println("**getFields:");
    	for (Field field:cls.getFields()){
    		System.out.println(field.getName());//获取字段的名称
    		int fieldValue = field.getModifiers();//获取字段的修饰符 如：private、static、final等
    		Modifier.isStatic(fieldValue);//与某个具体的修饰符进行比较看此修饰符是否为静态(static)
    		Modifier.isPublic(fieldValue);
    	}
    	//getDeclaredFields()：获得某个类的所有声明的字段，即包括public、private和proteced，但是不包括父类的申明字段。
    	System.out.println("**getDeclaredFields:");
    	for (Field field:cls.getDeclaredFields()){
    		System.out.println(field.getName());
    	}
	}
}