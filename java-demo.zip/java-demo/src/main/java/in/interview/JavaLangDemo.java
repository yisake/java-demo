package in.interview;

public class JavaLangDemo {

	public JavaLangDemo() {
		// TODO Auto-generated constructor stub
	}

	/**
    基本数据类型对象包装类 
 
    基本数据类型  引用数据类型 
    byte            Byte 
    short           Short 
    int             Integer 
    long            Long 
    float           Float 
    double          Double 
    char            Characher 
    boolean         Boolean 
	*/
	public static void main (String [] args) {
		System.out.println(Integer.SIZE);
		System.out.println(Float.SIZE);
		System.out.println(Double.SIZE);
	}
}
