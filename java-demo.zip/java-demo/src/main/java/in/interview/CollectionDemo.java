package in.interview;

import java.util.Collections;

public class CollectionDemo {

	public CollectionDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String []args) {
		
	}
}
