package ext.org.apache.httpcomponents;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;

@SuppressWarnings("deprecation")
public class HttpClient {
	
	/**
	这是个3.X的超时设置方法
	HttpClient client = newHttpClient();
	client.setConnectionTimeout(30000); 
	client.setTimeout(30000);
	
	4.X版本的超时设置(4.3后已过时)
	HttpClient httpClient=new DefaultHttpClient();
	httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,2000);//连接时间
	httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,2000);//数据传输时间
	
	4.3版本
	CloseableHttpClient httpClient = HttpClients.createDefault();
	HttpGet httpGet=newHttpGet("http://www.baidu.com");//HTTP Get请求(POST雷同)
	RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(2000).setConnectTimeout(2000).build();//设置请求和传输超时时间
	httpGet.setConfig(requestConfig);
	httpClient.execute(httpGet);//执行请求
		
	//4.5版本
	setConnectTimeout：设置连接超时时间，单位毫秒。
	setConnectionRequestTimeout：设置从connect Manager(连接池)获取Connection 超时时间，单位毫秒。这个属性是新加的属性，因为目前版本是可以共享连接池的。
	setSocketTimeout：请求获取数据的超时时间(即响应时间)，单位毫秒。 如果访问一个接口，多少时间内无法返回数据，就直接放弃此次调用。
	 */
	
	@Test
	public void get请求() throws ClientProtocolException, IOException{
		CloseableHttpClient httpclient = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet("http://example.com");  
		RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(5000).setConnectionRequestTimeout(1000).setSocketTimeout(5000).build();
		httpGet.setConfig(requestConfig);
		CloseableHttpResponse response = httpclient.execute(httpGet);
		System.out.println("得到的结果:" + response.getStatusLine());//得到请求结果
		response.getAllHeaders();
		HttpEntity entity = response.getEntity();//得到请求回来的数据
		System.out.println(entity.getContentLength());
		System.out.println(EntityUtils.toString(entity));
//		BufferedReader br = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
//		StringBuffer responseString = new StringBuffer();
//		String result = br.readLine();
//		while (result != null) {
//			responseString.append(result);
//			result = br.readLine();
//		}
//		System.out.println("Content:\n"+responseString.toString());
	}
	
	
	@Test
	public void post请求() throws ClientProtocolException, IOException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		String json="{\"name\":\"hf\"}";//提交json格式参数
		HttpPost post = new HttpPost("http://example.com");
		//增加header信息
		post.addHeader("device-id", "431243141");
        //设置代理IP、端口、协议（请分别替换）
        HttpHost proxy = new HttpHost("127.0.0.1", 8888, "http");
		//设置超时
		RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(5000).setConnectionRequestTimeout(1000).setSocketTimeout(5000).setProxy(proxy).build();
		post.setConfig(requestConfig);
		// 创建请求内容
		StringEntity stringEntity = new StringEntity(json, ContentType.APPLICATION_JSON);	
		post.setEntity(stringEntity);
		CloseableHttpResponse response = httpclient.execute(post);
		System.out.println("得到的结果:" + response.getStatusLine());//得到请求结果
		response.getAllHeaders();
		HttpEntity httpEntity = response.getEntity();//得到请求回来的数据
		System.out.println(httpEntity.getContentLength());
		System.out.println(EntityUtils.toString(httpEntity));
	}
	
	//提交form表单参数
	@Test
	public void post请求2() throws ParseException, IOException {
	    CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	    CloseableHttpResponse httpResponse = null;
	    HttpPost httpPost = new HttpPost("http://example.com/");
	    HttpHost proxy = new HttpHost("121.0.0.1", 8888, "http");
	    RequestConfig requestConfig = RequestConfig.custom().setProxy(proxy).setConnectTimeout(20000).setSocketTimeout(22000).build();
	    httpPost.setConfig(requestConfig);
	    List<NameValuePair> params = new ArrayList<NameValuePair>();
	    params.add(new BasicNameValuePair("user.loginId", "Lin"));
	    params.add(new BasicNameValuePair("user.employeeName","令狐冲"));
	    UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params,Charset.forName("UTF-8"));
	    httpPost.setEntity(entity);
	    httpResponse = httpClient.execute(httpPost);
	    HttpEntity responseEntity = httpResponse.getEntity();
	    if(responseEntity!=null){
	        String content = EntityUtils.toString(responseEntity,"UTF-8");
	        System.out.println(content);
	    }
	}	
	
	public void uploadFile() throws IOException {
	    CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	    RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(200000).setSocketTimeout(200000000).build();
	    HttpPost httpPost = new HttpPost("http://127.0.0.1:5000");
	    httpPost.setConfig(requestConfig);
	    MultipartEntityBuilder multipartEntityBuilder = MultipartEntityBuilder.create();
	    //multipartEntityBuilder.setCharset(Charset.forName("UTF-8"));
	    //File file = new File("F:\\Ken\\1.PNG");
	    //FileBody bin = new FileBody(file); 
	    File file = new File("F:\\Ken\\abc.pdf");
	    //multipartEntityBuilder.addBinaryBody("file", file,ContentType.create("image/png"),"abc.pdf");
	    //当设置了setSocketTimeout参数后，以下代码上传PDF不能成功，将setSocketTimeout参数去掉后此可以上传成功。上传图片则没有个限制
	    //multipartEntityBuilder.addBinaryBody("file",file,ContentType.create("application/octet-stream"),"abd.pdf");
	    multipartEntityBuilder.addBinaryBody("file",file);
	    //multipartEntityBuilder.addPart("comment", new StringBody("This is comment", ContentType.TEXT_PLAIN));
	    multipartEntityBuilder.addTextBody("comment", "this is comment");
	    HttpEntity httpEntity = multipartEntityBuilder.build();
	    httpPost.setEntity(httpEntity);
	    CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
	    HttpEntity responseEntity = httpResponse.getEntity();
	    int statusCode= httpResponse.getStatusLine().getStatusCode();
	    if(statusCode == 200){
	        BufferedReader reader = new BufferedReader(new InputStreamReader(responseEntity.getContent()));
	        StringBuffer buffer = new StringBuffer();
	        String str = "";
	        while(!StringUtils.isEmpty(str = reader.readLine())) {
	            buffer.append(str);
	        }
	        System.out.println(buffer.toString());
	    }
	    httpClient.close();
	    if(httpResponse!=null){
	        httpResponse.close();
	    }
	}
	
	@Test
	public void uploadFile1() throws Exception, IOException{
	       CloseableHttpClient httpclient = HttpClients.createDefault(); 
           HttpPost httppost = new HttpPost("http://localhost:8080/WEY.WebApp/auth/right/right/receiveFile.html"); 
           RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(200000).setSocketTimeout(200000).build();
           httppost.setConfig(requestConfig);
           FileBody bin = new FileBody(new File("F:\\Ken\\abc.pdf")); 
           StringBody comment = new StringBody("This is comment", ContentType.TEXT_PLAIN); 
           HttpEntity reqEntity = MultipartEntityBuilder.create().addPart("file", bin).addPart("comment", comment).build(); 
           httppost.setEntity(reqEntity); 
           System.out.println("executing request " + httppost.getRequestLine()); 
           CloseableHttpResponse response = httpclient.execute(httppost); 
           System.out.println(response.getStatusLine()); 
           HttpEntity resEntity = response.getEntity(); 
           if (resEntity != null) { 
               String responseEntityStr = EntityUtils.toString(response.getEntity());
               System.out.println(responseEntityStr);
               System.out.println("Response content length: " + resEntity.getContentLength()); 
           } 
           EntityUtils.consume(resEntity);
	}
	
	@Test
	public String defaultHttpClient() throws ClientProtocolException, IOException{
		String json="";
		@SuppressWarnings({ "resource" })
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpHost proxy = new HttpHost("127.0.0.1",8888);
		httpClient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);
		HttpPost httpPost = new HttpPost("http://www.baidu.com/");
		httpPost.addHeader(HTTP.CONTENT_TYPE, "application/json");
		StringEntity se = new StringEntity(json, "UTF-8");
		httpPost.setEntity(se);
		HttpResponse httpResponse=httpClient.execute(httpPost);
		HttpEntity entity = httpResponse.getEntity();
		BufferedReader br = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"));
		StringBuffer responseString = new StringBuffer();
		String result = br.readLine();
		while (result != null) {
			responseString.append(result);
			result = br.readLine();
		}
		return responseString.toString();
	}
}
