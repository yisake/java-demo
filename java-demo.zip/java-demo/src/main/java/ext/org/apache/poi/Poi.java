package ext.org.apache.poi;

import java.io.FileInputStream;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Workbook;
import org.testng.annotations.Test;

public class Poi {
	
	/**
	 * 	●  HSSF -- 提供读写Microsoft Excel格式档案的功能。
		●  XSSF -- 提供读写Microsoft Excel OOXML格式档案的功能。
		●  HWPF -- 提供读写Microsoft Word格式档案的功能。
		●  HSLF -- 提供读写Microsoft PowerPoint格式档案的功能。
		●  HDGF -- 提供读写Microsoft Visio格式档案的功能。
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		String excelFile="";
//		Workbook book = null;
//		try {
//		    book = new XSSFWorkbook(excelFile);
//		} catch (Exception ex) {
//		    book = new HSSFWorkbook(new FileInputStream(excelFile));
//		}
//
//		POIFSFileSystem poifsFileSystem = new POIFSFileSystem(new FileInputStream(excel));
//		HSSFWorkbook workbook = new HSSFWorkbook(poifsFileSystem);
//		HSSFSheet sheet = workbook.getSheetAt(0);
	}
	
	@Test
    public int JumpFloorII() {
		System.out.println("####");
		int target=5;
		if(target<=0){
            return 0;
        }
        if(target==1){
            return 1;
        }
        int first =1;
        int second=0;
        for(int i=2;i<=target;i++){
            second=2*first;
            first=second;
        }
        System.out.println(second);
        return second;
    }
	


}
