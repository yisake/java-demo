package ext.org.apache.commons.lang3;

import java.util.Arrays;
import org.apache.commons.lang3.SystemUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;

public class CommonLang {
	
	public  void arrayUtils() {
		//11.  移除数组中的元素 
		int[] intArray11 = { 1, 2, 3, 4, 5 };  
		int[] removed = ArrayUtils.removeElement(intArray11, 3);//create a new array  
		System.out.println(Arrays.toString(removed));  	
		
		//5.连接两个数组 
		int[] intArray1 = { 1, 2, 3, 4, 5 };  
		int[] intArray2 = { 6, 7, 8, 9, 10 };  
		//**Apache Commons Lang library  
		int[] combinedIntArray = ArrayUtils.addAll(intArray1, intArray2);
		System.out.println(combinedIntArray.length);
	}
	
	public  void objectUtils() {
		String a = null;
		String b = "";
		ObjectUtils.allNotNull(a,b);
	}
	
	public  void randomUtils(){
		RandomUtils.nextBoolean();
		RandomUtils.nextDouble();
		RandomUtils.nextInt();
		RandomUtils.nextLong();
		RandomUtils.nextBytes(5);
	}
	
	public  void systemUtils(){
		System.out.println(SystemUtils.IS_JAVA_10);
		System.out.println(SystemUtils.JAVA_HOME);
	}

	public  void stringUtils(){
		StringUtils.compare("", "");
		
		StringUtils.trim("");
		StringUtils.trimToEmpty("");//去除字符串空格，null转为empty，返回一个string
	}
	
}
