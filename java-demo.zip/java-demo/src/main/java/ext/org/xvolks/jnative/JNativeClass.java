package ext.org.xvolks.jnative;

import org.xvolks.jnative.exceptions.NativeException;
import org.xvolks.jnative.misc.basicStructures.HWND;
import org.xvolks.jnative.misc.basicStructures.LPARAM;
import org.xvolks.jnative.misc.basicStructures.UINT;
import org.xvolks.jnative.misc.basicStructures.WPARAM;
import org.xvolks.jnative.util.User32;

public class JNativeClass {

	public static void main(String[] args) throws IllegalAccessException, NativeException {
		// TODO Auto-generated method stub
        HWND hWnd = User32.FindWindow("TXGuiFoundation", "QQ2010");  
        if(hWnd.getValue()>0){  
            System.out.println("window exists");  
            User32.SendMessage(hWnd, new UINT(0x10), new WPARAM(0), new LPARAM(0));  
        }else{  
            System.out.println("window doesn't exists");  
        }

	}
}
