package ext.com.fasterxml.jackson;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Jackson {

	public static void main(String[] args) throws ParseException, IOException {
		// TODO Auto-generated method stub
		java2json();
		json2java();
	}
	
	/**
	 * JAVA对象转JSON[JSON序列化]
	 * @throws JsonProcessingException
	 * @throws ParseException
	 */
	public static void java2json() throws JsonProcessingException, ParseException {
		User user=new User();
		user.setName("zhangsan");
		user.setAge(23);
		user.setEmail("zhangsan@qq.com");		
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        user.setBirthday(dateformat.parse("1996-10-01"));
        
		/**
		 * ObjectMapper是JSON操作的核心，Jackson的所有JSON操作都是在ObjectMapper中实现。
		 * ObjectMapper有多个JSON序列化的方法，可以把JSON字符串保存File、OutputStream等不同的介质中。
		 * writeValue(File arg0, Object arg1)把arg1转成json序列，并保存到arg0文件中。
		 * writeValue(OutputStream arg0, Object arg1)把arg1转成json序列，并保存到arg0输出流中。
		 * writeValueAsBytes(Object arg0)把arg0转成json序列，并把结果输出成字节数组。
		 * writeValueAsString(Object arg0)把arg0转成json序列，并把结果输出成字符串。
		 */
        ObjectMapper mapper = new ObjectMapper();
        //User类转JSON
        //输出结果：{"name":"zhangsan","age":20,"birthday":844099200000,"email":"zhangsan@163.com"}
        String json = mapper.writeValueAsString(user);
        System.out.println("####java to json:");
        System.out.println(json);
        
        List<User>users=new ArrayList<User>();
        users.add(user);
        String jsonlist= mapper.writeValueAsString(users);
        System.out.println(jsonlist);		
	}
	
	
	public static void json2java() throws JsonParseException, JsonMappingException, IOException{
        //ObjectMapper支持从byte[]、File、InputStream、字符串等数据的JSON反序列化。
		String json = "{\"name\":\"zhangsan\",\"age\":20,\"birthday\":844099200000,\"email\":\"zhangsan@163.com\"}";
		ObjectMapper mapper=new ObjectMapper();
		User user = mapper.readValue(json, User.class);
		String jsonlist = "[{\"name\":\"zhangsan\",\"age\":20,\"birthday\":844099200000,\"email\":\"zhangsan@163.com\"}]";
		List<User>beanlist=mapper.readValue(jsonlist, new TypeReference<List<User>>() {});
		System.out.println("####json to java:");
        System.out.println(user);
        System.out.println(beanlist);
	}
	
	/**
	* Jackson提供了一系列注解，方便对JSON序列化和反序列化进行控制，下面介绍一些常用的注解。
	 * @throws JsonProcessingException 
	 * @throws ParseException 
	*	@JsonIgnore 此注解用于属性上，作用是进行JSON操作时忽略该属性。
	*	@JsonFormat 此注解用于属性上，作用是把Date类型直接转化为想要的格式，如@JsonFormat(pattern = "yyyy-MM-dd HH-mm-ss")。
	*	@JsonProperty 此注解用于属性上，作用是把该属性的名称序列化为另外一个名称，如把trueName属性序列化为name，@JsonProperty("name")。
	*/
	public static void jsonAnnotation() throws JsonProcessingException, ParseException{
		User user=new User();
		user.setName("zhangsan");
		user.setAge(23);
		user.setEmail("zhangsan@qq.com");
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        user.setBirthday(dateformat.parse("1996-10-01"));		
		
		ObjectMapper mapper=new ObjectMapper();
		String json = mapper.writeValueAsString(user);
        System.out.println(json);
	}
}
