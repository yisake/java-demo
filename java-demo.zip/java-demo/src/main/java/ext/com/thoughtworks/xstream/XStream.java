package ext.com.thoughtworks.xstream;

/**
 * XStream是一个简单的将javabean转换为XML形式的框架，非常的简单方便，同时对于注解也是支持的，也是很简单！
 * @author huangfucf
 *
 */
public class XStream {
	
}
