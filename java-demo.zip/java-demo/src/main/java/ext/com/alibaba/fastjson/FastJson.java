package ext.com.alibaba.fastjson;

import java.io.Serializable;
import java.util.List;
import org.testng.Reporter;
import org.testng.annotations.Test;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONPath;
import com.alibaba.fastjson.annotation.*;
import com.alibaba.fastjson.util.IOUtils;

public class FastJson {
	private String JSON_OBJ_STR = "{\"studentName\":\"莉莉\",\"studentAge\":12}";
	private String JSON_ARRAY_STR = "[{\"studentName\":\"莉莉\",\"studentAge\":12},{\"studentName\":\"lucy\",\"studentAge\":15}]";
	private String COMPLEX_JSON_STR = "{\"teacherName\":\"克丽丝\",\"teacherAge\":27,\"course\":{\"courseName\":\"英文\",\"code\":1270},\"students\":[{\"studentName\":\"莉莉\",\"studentAge\":12},{\"studentName\":\"露西\",\"studentAge\":15}],\"sign\":\"WMNM7l5twe4r4dk0yagV2w2pViU5o5N24AluZ\",\"sign_type\":\"RSA\"}";
	private String BOOK_STORE= "{\"store\":{\"book\":[{\"title\":\"高效Java\",\"price\":10},{\"title\":\"研磨设计模式\",\"price\":12},{\"title\":\"重构\",\"isbn\":\"553\",\"price\":8},{\"title\":\"虚拟机\",\"isbn\":\"395\",\"price\":22}],\"bicycle\":{\"color\":\"red\",\"price\":19}}}";

	@Test(description = "json序列化，反序列化")
	public void jsonJSON() {
		User user=new User("test001","marks",105);
		Reporter.log("##java对象序列化为json字符串",true);
		String text=JSON.toJSONString(user);
		this.formatJson(text);
		
		Reporter.log("##java对象序列化为json对象",true);
        JSONObject jsonObj4 = (JSONObject) JSON.toJSON(user);
        this.formatJson(jsonObj4.toString());
		
        Reporter.log("##json字符串反序列化为json对象",true);
        JSONObject json2 = JSON.parseObject(COMPLEX_JSON_STR);  
        this.formatJson(json2.toString());
		
        Reporter.log("##json字符串反序列化为java对象",true);
        User user3 = (User) JSON.parseObject(JSON_OBJ_STR, User.class);  
        System.out.println("user==" + user3.getId() + "\n" + user3.getName() + "\n" + user3.getAge());
	}
	
	@Test
	public void jsonJSONObject(){
		Reporter.log("####JSONObject插入： put",true);
		JSONObject securedQuery=new JSONObject();
		securedQuery.put("timestamp", "20180829105500");
		securedQuery.put("oid_partner", "2018062800003003");
		securedQuery.put("accp_txno", "2018082916220985");
		securedQuery.put("txn_seqno", "20190126");
		this.formatJson(securedQuery.toString());//toJSONString()
		
		Reporter.log("####JSONObject查询：get",true);
		Reporter.log("accp_txno:"+(String) securedQuery.get("accp_txno"),true);
		
		Reporter.log("####JSONObject查询：getString,getInteger",true);
		JSONObject jsonObject1=JSONObject.parseObject(COMPLEX_JSON_STR);
		this.formatJson(jsonObject1.toJSONString());
		Reporter.log("name:"+jsonObject1.getString("studentName"),true);
		Reporter.log("age:"+jsonObject1.getInteger("studentAge"),true);
		
		Reporter.log("####JSONObject查询：containsKey",true);
		Reporter.log("accp_txno:"+securedQuery.containsKey("accp_txno"),true);
		Reporter.log("####JSONObject查询：containsValue",true);
		Reporter.log("2018062800003003:"+securedQuery.containsValue("2018062800003003"),true);
	}
	
	@Test
	public void jsonJSONArray(){
		JSONArray ja=(JSONArray) JSONArray.parse(JSON_ARRAY_STR);
		JSONObject jo=(JSONObject) ja.get(0);
		System.out.println("####get");
		System.out.println("student name:"+jo.get("studentName"));
		
	}	
	
	@Test
	public void jsonJSONPath(){
		//eval()方法，取值，关键是后面的路径的语法；
		//read()方法，
		//contains()，containsValue()，判断值的有无；
		//set()，设置值；
		//arrayAdd，在数组或者集合中添加元素；
		//remove，删除；
		JSONObject jo=JSON.parseObject(this.COMPLEX_JSON_STR);
		this.formatJson(jo.toString());
		System.out.println("老师名字："+JSONPath.eval(jo, "$.teacherName"));
		System.out.println("学生1名字："+JSONPath.eval(jo, "$.students[0].studentAge"));
		System.out.println("设置：");
		JSONPath.set(jo, "$.sign_type", "MD5");
		this.formatJson(jo.toString());			
		System.out.println("删除：");
		JSONPath.remove(jo, "$.sign");
		this.formatJson(jo.toString());
	}
	
	@Test
	public void jsonJSONPath2(){

//		$	表示根元素
//		@	当前元素
//		. or []	子元素
//		n/a	父元素
//		..	递归下降，JSONPath是从E4X借鉴的。
//		*	通配符，表示所有的元素
//		?()	应用过滤表示式
//		[num]	数组访问，其中num是数字，可以是负数。例如$[0].leader.departments[-1].name
//		[num0,num1,num2…]	数组多个元素访问，其中num是数字，可以是负数，返回数组中的多个元素。例如$[0,3,-2,5]
//		[start:end]	数组范围访问，其中start和end是开始小表和结束下标，可以是负数，返回数组中的多个元素。例如$[0:5]
//		[start:end:step]	数组范围访问，其中start和end是开始小表和结束下标，可以是负数；step是步长，返回数组中的多个元素。例如$[0:5:2]
//		[ ?(key) ]	对象属性非空过滤，例如$.departs[?(name)]
//		[ key > 123]	数值类型对象属性比较过滤，例如$.departs[id >= 123]，比较操作符支持=,!=,>,>=,<,<=
//		[ key = ‘123’]	字符串类型对象属性比较过滤，例如$.departs[name = ‘123’]，比较操作符支持=,!=,>,>=,<,<=
//		[ key like ‘aa%’]	字符串类型like过滤，例如$.departs[name like ‘sz*’]，通配符只支持% 支持not like
//		[ key rlike ‘regexpr’]	字符串类型正则匹配过滤，例如departs[name like ‘aa(.)*’]，正则语法为jdk的正则语法，支持not rlike
//		[ key in (‘v0’, ‘v1’)]	IN过滤, 支持字符串和数值类型。例如: $.departs[name in (‘wenshao’,’Yako’)]，$.departs[id not in (101,102)]
//		[ key between 234 and 456]	BETWEEN过滤, 支持数值类型，支持not between。例如: $.departs[id between 101 and 201]，$.departs[id not between 101 and 201]
//		length() 或者 size()	数组长度。例如$.values.size() 支持类型java.util.Map和java.util.Collection和数组
//		[‘key’]	属性访问。例如$[‘name’]
//		[‘key0’,’key1’]	多个属性访问。例如$[‘id’,’name’]
//		--------------------- 
//		作者：B8613A 
//		来源：CSDN 
//		原文：https://blog.csdn.net/liupeifeng3514/article/details/79180154 
//		版权声明：本文为博主原创文章，转载请附上博文链接！
		
		this.formatJson(this.BOOK_STORE);
        List<Object> titles = (List<Object>) JSONPath.read(BOOK_STORE, "$.store.book.title"); // 获取json中store下book下的所有title值
        System.out.println("表达式 $.store.book.title= " + titles);              
        titles = (List<Object>) JSONPath.read(BOOK_STORE, "$..title");// 获取json中所有title的值 
        System.out.println("表达式 $..title= " + titles);        
        List<Object> isbns = (List<Object>) JSONPath.read(BOOK_STORE, "$.store.book[?(@.isbn)]");// 获取json中book数组中包含isbn的所有值
        System.out.println("表达式 $.store.book[?(@.isbn)] = " + isbns);        
        List<Object> prices = (List<Object>) JSONPath.read(BOOK_STORE, "$.store.book[?(@.price < 10)]");// 获取json中book数组中price<10的所有值
        System.out.println("表达式 $.store.book[?(@.price < 10)] = " + prices);        
        titles = (List<Object>) JSONPath.read(BOOK_STORE, "$.store.book[?(@.title = '高效Java')]");// 获取json中book数组中的title等于“高效Java”的对象
        System.out.println("表达式 $.store.book[?(@.title = '高效Java')] = " + titles);       
        prices = (List<Object>) JSONPath.read(BOOK_STORE, "$.store..price");// 获取json中store下所有price的值
        System.out.println("表达式 $.store..price = " + prices);       
        List<Object> books = (List<Object>) JSONPath.read(BOOK_STORE, "$.store.book[:2]");// 获取json中book数组的前两个区间值
        System.out.println("表达式 $.store.book[:2] = " + books);       
        int size = (int) JSONPath.read(BOOK_STORE, "$.store.book.size()");// 获取书个数
        System.out.println("表达式 $.store.book.size() = " + size);
	}	
	
	@Test
	public String formatJson(String jsonStr) {
	    if (null == jsonStr || "".equals(jsonStr))
	        return "";
	    StringBuilder sb = new StringBuilder();
	    char last = '\0';
	    char current = '\0';
	    int indent = 0;
	    boolean isInQuotationMarks = false;
	    for (int i = 0; i < jsonStr.length(); i++) {
	        last = current;
	        current = jsonStr.charAt(i);
	        switch (current) {
	        case '"':
	                            if (last != '\\'){
	                isInQuotationMarks = !isInQuotationMarks;
	                            }
	            sb.append(current);
	            break;
	        case '{':
	        case '[':
	            sb.append(current);
	            if (!isInQuotationMarks) {
	                sb.append('\n');
	                indent++;
	                addIndentBlank(sb, indent);
	            }
	            break;
	        case '}':
	        case ']':
	            if (!isInQuotationMarks) {
	                sb.append('\n');
	                indent--;
	                addIndentBlank(sb, indent);
	            }
	            sb.append(current);
	            break;
	        case ',':
	            sb.append(current);
	            if (last != '\\' && !isInQuotationMarks) {
	                sb.append('\n');
	                addIndentBlank(sb, indent);
	            }
	            break;
	        default:
	            sb.append(current);
	        }
	    }
	    System.out.println(sb.toString());
	    return sb.toString();
	}
	
	public void addIndentBlank(StringBuilder sb, int indent) {
	    for (int i = 0; i < indent; i++) {
	        sb.append('\t');
	    }
	}
	
	public class User implements Serializable {  
	      
	    private static final long serialVersionUID = 1L;  
	      
	    private String id;  
	    private String name;  
	    private int age;  
	      
	    public User() {  
	        super();  
	    }  
	  
	    public User(String id, String name, int age) {  
	        super();  
	        this.id = id;  
	        this.name = name;  
	        this.age = age;  
	    }  
	  
	    public int getAge() {  
	        return age;  
	    }  
	  
	    public void setAge(int age) {  
	        this.age = age;  
	    }  
	  
	    public String getId() {  
	        return id;  
	    }  
	  
	    public void setId(String id) {  
	        this.id = id;  
	    }  
	  
	    public String getName() {  
	        return name;  
	    }  
	  
	    public void setName(String name) {  
	        this.name = name;  
	    }  
	      
	}
}
