package ext.commons.logging;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 简介：
 *	Jakarta  Commons-logging（JCL）是apache最早提供的日志的门面接口。提供简单的日志实现以及日志解耦功能。
 *
 * 原理：
 *	JCL有两个基本的抽象类： Log( 基本记录器 ) 和 LogFactory( 负责创建 Log 实例 ) 。当 commons-logging.jar 被加入到 CLASSPATH之后，它会合理地猜测你想用的日志工具，然后进行自我设置，用户根本不需要做任何设置。默认的 LogFactory 是按照下列的步骤去发现并决定那个日志工具将被使用的（按照顺序，寻找过程会在找到第一个工具时中止） :
 *
 * 1.首先在classpath下寻找commons-logging.properties文件。如果找到，则使用其中定义的Log实现类；如果找不到，则在查找是否已定义系统环境变量org.apache.commons.logging.Log，找到则使用其定义的Log实现类；
 * 2.查看classpath中是否有Log4j的包，如果发现，则自动使用Log4j作为日志实现类；
 * 3.否则，使用JDK自身的日志实现类（JDK1.4以后才有日志实现类）；
 * 4.否则，使用commons-logging自己提供的一个简单的日志实现类SimpleLog；

	org.apache.commons.logging.Log 的具体实现有如下：
	---org.apache.commons.logging.impl.Jdk14Logger 　使用 JDK1.4 。
	---org.apache.commons.logging.impl.Log4JLogger 　使用 Log4J 。
	---org.apache.commons.logging.impl.LogKitLogger    使用 avalon-Logkit 。
	---org.apache.commons.logging.impl.SimpleLog   common-logging 自带日志实现类。
	---org.apache.commons.logging.impl.NoOpLog   common-logging 自带日志实现类。它实现了 Log 接口。 其输出日志的方法中不进行任何操作。
 * @author huangfucf
 */
public class Logging {
	private final static  Log logger = LogFactory.getLog(Logging.class);	
	public static void main(String[] args) {
		simpleLog();
		log4j();
	}
	
	public static void simpleLog(){
		logger.debug("**DEBUG...");
		logger.info("**INFO ...");  
        logger.error("**ERROR ...");		
	}
	
	public static void log4j(){
        logger.debug("##DEBUG ...");  
        logger.info("##INFO ...");  
        logger.error("##ERROR ...");
	}
}
