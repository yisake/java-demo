package ext.commons.dbutils;

import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.SQLException;  
import java.util.ArrayList;  
import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;  
import org.apache.commons.dbutils.handlers.BeanListHandler;  
  
  
  
/** 
 * 使用QueryRunner 类实现CRUD（create，read,update,delete） 
 * @author Administrator 
 * 
 */  
public class CommonDbutils {  
  
    /* 
     测试表 
     create table stuInfo 
    ( 
        stuNo int primary key identity (1,1),--学号 
        stuName nvarchar(10) not null,--学生姓名 
        stuSex nvarchar(2) not null,--学生性别 
        stuAge int not null,--学生年龄 
        stuSeat int not null,--学生座位 
        stuAddress nvarchar(20) --学生住址 
         
    )*/  
      
    public static void main(String[] args) {  
        CommonDbutils test = new CommonDbutils();  
        test.add();  
        test.delete();  
        test.update();  
        test.find();  
        //test.getAll();
  
    }  
      
    private static Connection getConnection() {  
        Connection conn = null;  
        try {  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;Database=student", "sa", "sasa");  
        } catch (SQLException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        } catch (ClassNotFoundException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
        System.out.println(conn);  
        return conn;  
          
    }  
      
    //添加方法  
    public void add () {  
        Connection conn = getConnection();  
        QueryRunner qr = new QueryRunner();  
        String sql = "insert into stuInfo (stuName,stuSex,stuAge,stuSeat,stuAddress) values (?,?,?,?,?)";  
        Object param[] = {"张良","男",20,11,"韩国"};  
        int i;  
        try {  
            i = qr.update(conn, sql, param);  
            System.out.println("添加成功："+i);  
        } catch (SQLException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
    }  
      
    //删除方法  
    public void delete() {  
        Connection conn = getConnection();  
        QueryRunner qr = new QueryRunner();  
        String sql ="delete from stuInfo where stuNo=?";  
        try {  
            int i = qr.update(conn, sql, 7);  
            System.out.println("删除成功："+i);  
        } catch (SQLException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
    }  
      
    //修改方法  
    public void update() {  
        Connection conn = getConnection();  
        QueryRunner qr = new QueryRunner();  
        String sql = "update stuInfo set stuName=? where stuNo=?";  
        Object params[] = {"胡歌",3};  
        try {  
            int i = qr.update(conn, sql, params);  
            System.out.println("修改成功："+i);  
        } catch (SQLException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
    }  
      
    //查询方法  
    public void find() {  
        Connection conn = getConnection();  
        QueryRunner qr = new QueryRunner();  
        String sql = "select * from stuInfo where stuNo=?";  
        Object params[] = {5};  
//        try {  
//            StuInfo stuInfo = (StuInfo)qr.query(conn, sql, new BeanHandler<StuInfo>(StuInfo.class), params);  
//            System.out.println("查询成功："+stuInfo);  
//        } catch (SQLException e) {  
//            // TODO Auto-generated catch block  
//            e.printStackTrace();  
//        }  
    }  
      
//    //查询所有  
//    public void getAll() {  
//        Connection conn = getConnection();  
//        QueryRunner qr = new QueryRunner();  
//        String sql ="select * from stuInfo";  
//        ArrayList<StuInfo> list;  
//        try {  
//            list = (ArrayList<StuInfo>) qr.query(conn, sql, new BeanListHandler<StuInfo>(StuInfo.class));  
//            for (StuInfo stuInfo : list) {  
//                System.out.println(stuInfo);  
//            }  
//        } catch (SQLException e) {  
//            // TODO Auto-generated catch block  
//            e.printStackTrace();  
//        }  
//          
//    }
}