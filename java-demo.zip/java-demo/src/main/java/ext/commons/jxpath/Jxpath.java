package ext.commons.jxpath;

public class Jxpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
