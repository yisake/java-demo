package ext.commons.lang;

public class CommonsLang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
