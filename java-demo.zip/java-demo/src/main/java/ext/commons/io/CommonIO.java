package ext.commons.io;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.testng.annotations.Test;

public class CommonIO {
	
	@Test
	public  void fileutil() throws IOException {
        String filePath1 = "F:/dd" ;
        File file1 = new File( filePath1 ) ;

        String filePath2 = "F:/ee" ;
        File file2 = new File( filePath2 ) ;        
		FileUtils.copyFile(file1, file2); //复制文件
		FileUtils.copyDirectory(file1, file2); //复制文件夹
		
		String url = "http://imgsrc.baidu.com/baike/pic/item/7aec54e736d12f2ee289bffe4cc2d5628435689b.jpg" ;
        //String filePath3 = "F:/abc.jpg" ;
        File file3 = new File( filePath2 ) ;
        FileUtils.copyURLToFile( new URL( url ) , file3 );//下载文件
        FileUtils.writeStringToFile(file3, "下班了", "UTF-8",true);//写入字符串
        FileUtils.writeByteArrayToFile(file3, "下班了".getBytes());//字节数组写入文件
        //写入集合set
	}
}
